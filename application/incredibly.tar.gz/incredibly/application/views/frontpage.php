<div data-vide-bg="video/training" class="video_margin" style="position: relative;">

<div style="position: absolute; z-index: -1; top: 0px; left: 0px; bottom: 0px; right: 0px; overflow: hidden; background-size: cover; background-repeat: no-repeat; background-position: 50% 50%; background-image: url(&quot;http://grandrehabber.com/video/training.jpeg&quot;);">

<video autoplay="" loop="" muted="" style="margin: auto; position: absolute; z-index: -1; top: 50%; left: 50%; transform: translate(-50%, -50%); visibility: visible; width: 100%; height: auto;">
	<source src="<?=base_url()?>assets/video/training.mp4" type="video/mp4">
	<source src="assets/video/training.webm" type="video/webm"><source src="video/training.ogv" type="video/ogg">
	</video>
</div>
	
<div class="center-container">
 <div class="ban-shade">
	<div class="header-nav">
		<div class="clearfix"></div>	
		</div>
        
			<div class="box_1-top">
				<div class="banner-info wow fadeInLeft animated" data-wow-delay=".5s">
               <h2>Build Your Real Estate Portfolio</h2>
					<h3>end-to-end services of property selection</h3>
               <h3>acquisition, management and sale to match your financial goals.</h3>
               <a href="<?=base_url()?>get-started" title="GET STARTED" class="hvr-shutter-in-vertical button" style="margin-top: 30px;">GET STARTED</a>		
               <a class="hvr-shutter-in-vertical button" data-toggle="modal" data-target="#videoModal" data-thevideo="assets/video/training.mp4" style="margin-top: 30px;">PLAY VIDEO</a>
				</div>
			</div>
		</div>
    </div>
</div>
 <script>window.jQuery || document.write('<script src="<?=base_url()?>assets/js/vendor/jquery-1.11.1.min.js"><\/script>')</script>
<!--banner bottom-->
<div class="about">
  <div class="col-md-2"></div>
	 <div class="col-md-8 about-left wow fadeInRight animated" data-wow-delay=".5s">
		<h3>You Invest, We Can Do the Rest</h3>
		<div class="text-center" style="overflow-x:auto;">
			<iframe src="https://calendar.google.com/calendar/embed?showTitle=0&amp;showTz=0&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;src=athinjofs%40gmail.com&amp;color=%231B887A&amp;ctz=America%2FNew_York" style="border-width:0" width="800" height="600" frameborder="0" scrolling="no"></iframe>

			<div class="row">
				<a style=" display:inline-block; border:solid 4px rgba(226, 23, 55, 1); background-color:rgba(226, 23, 55, 1); color:rgba(255, 255, 255, 1); padding:1rem 2rem; cursor:pointer; text-decoration:none; margin: 10px 0;" href="https://10to8.com/book/1db0d4c4-d0c9-4c19-b4e7-6647b763e573/uuid/" > Schedule a Appointment </a>
				 <script> (function() { var xhr = new XMLHttpRequest(); xhr.open("GET", "https://10to8.com/pub-api/book-now-button/1db0d4c4-d0c9-4c19-b4e7-6647b763e573/"); xhr.send(); })(); </script>
			</div>
		</div>
		<p>Tell us your investment goals, and we’ll help you build a real estate investment plan that will help you reach them. When you’re ready to buy, our experts will take care of the entire acquisition process as well as the ongoing management of the property. We’ll also provide you with market intelligence for buy, hold or sell decisions. Our goals are to maximize your returns, protect your assets and provide you with 100% transparency in the process. </p>
	</div>
	<div class="col-md-2"></div>
	<div class="clearfix"></div>
</div>
<!--//banner bottom-->
<!--content-->
<div class="content">
	<div class="container">
		<div class="col-md-6 content-left wow fadeInLeft animated" data-wow-delay=".5s">
			<h4>Do you have what it takes to be part of the Incrediblybuilt ?</h4>
			<p> As a unique real estate investment company, we are looking for the best and brightest to help us change the way people invest in real estate. Headquartered in Irvine, California, HomeUnion is growing rapidly and is seeking to hire top talent to help fuel its growth.</p>
			<a href="<?=base_url()?>comingsoon" title="" class="hvr-shutter-in-vertical button">More about us</a>		</div>
		<div class="col-md-6 content-right wow fadeInRight animated" data-wow-delay=".5s">
			<a href="<?=base_url()?>our-current-rehab" title="See Our Current Rehab">
				<div class="con-left text-center">
					<span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
					<h5>See Our Current Rehab</h5>
					<p>Learn how we rehab rental homes. While the outcome for each property is unique, we have many quality renovation examples.</p>
				</div>
			</a>
			<div class="con-left text-center">
				<span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
				<a href="<?=base_url()?>contact-us" title="Have Questions">
					<h5>Have Questions?</h5>
					<p>Contact us with your questions and an experienced team member will get in touch with you shortly.</p>
				</a>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!--//content-->
<!--staff-->
<div class="rooms">
	<div class="container">
		<h3>Ready to Start the Financing Process</h3>
		<div class="col-md-4 room-left wow fadeInRight animated" data-wow-delay=".5s">
			<div id="accordion">
				<h4>Find A Property</h4>
				    <div class="faculty-list">
						<ul>
							<li>Based on your personal investment goals, we build you an online portfolio of pre-vetted properties.</li>
						</ul>
				    </div>
				<h4>Fund Your Investment</h4>
				    <div class="faculty-list">
						<ul>
						    <li>We will help you decide on the best funding option to meet your investment goals.</li>
						</ul>
				    </div>
				<h4>Acquire the Property</h4>
				    <div class="faculty-list">
						<ul>
							<li>We do all the legwork for you to own your investment property.</li>
						</ul>
				    </div>
				<h4>Rehab Your Property</h4>
			    <div class="faculty-list">
					<ul>
						<li>We do all the legwork for you to own your investment property.</li>
					</ul>
			    </div>
			</div>
		</div>
		<div class="col-md-8 room-right wow fadeInLeft animated" data-wow-delay=".5s">
			<div class="sap_tabs">
			<div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
				  <ul class="resp-tabs-list">
					  <li class="resp-tab-item" aria-controls="tab_item-0" role="tab"><span>Our Benefits</span></li>
					  <li class="resp-tab-item" aria-controls="tab_item-1" role="tab"><span>How It Works</span></li>
					  <li class="resp-tab-item" aria-controls="tab_item-2" role="tab"><span>Seminars</span></li>
					  <li class="resp-tab-item" aria-controls="tab_item-3" role="tab"><span>Help</span></li>
					  <div class="clearfix"></div>
				  </ul>				  	 
				<div class="resp-tabs-container">
					<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-0">
						<div class="tab_img">
							<div class="sem-right">
								<img src="assets/img/sem3.jpg" alt="alt-tag">							</div>
							<div class="best-left sem-best">
								<h4>What We Do for You</h4>
								<ul>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Maximize Your Returns </a></li>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Reduce Your Risk</a></li>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Keep Renters Happy</a></li>
								</ul>
							</div>
							<div class="clearfix"></div>
						</div>	
						</div>								 
					</div>
					<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-1">
						<div class="tab_img">
							<div class="best-left">
								<h4>How It Works</h4>
								<ul>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Gather Documents</a></li>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Loan Structure</a></li>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Pre-Approval</a></li>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Escrow</a></li>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Funding</a></li>
								</ul>
							</div>
							
						</div>	 	        					 
					</div>
					<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-2">
						<div class="tab_img">
							<div class="sem-left">
							     <img src="<?=base_url()?>assets/img/sem1.jpg" alt="alt-tag">						
							     	</div>	
							<div class="sem-right">
								<img src="<?=base_url()?>assets/img/sem2.jpg" alt="alt-tag">								
								<img src="<?=base_url()?>assets/img/sem3.jpg" alt="alt-tag">						
									</div>
							<div class="clearfix"></div>
						</div>		        					 
					</div>
					<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-3">
						<div class="tab_img">
							<div class="sem-right">
								<img src="<?=base_url()?>assets/img/sem2.jpg" alt="alt-tag">							
									<img src="<?=base_url()?>assets/img/sem3.jpg" alt="alt-tag">			
													</div>
							<div class="best-left sem-best">
								<h4>What We Do for You</h4>
								<ul>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Marketing </a></li>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Property Showings </a></li>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Tenant Screening </a></li>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Repairs and Maintenance </a></li>
									<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Rent Collection</a></li>
								</ul>
							</div>
							<div class="clearfix"></div>
						</div>		
					</div>
				</div>	
			</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!--//staff-->
<!--footer-top-->
<div id="faculty" class="footer-top wow fadeInLeft animated" data-wow-delay=".5s">
	<div class="container">
		<h3>Who's Talking About Incrediblybuilt ?</h3>
		<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
			
			<div id="myTabContent" class="tab-content">
				<div role="tabpanel" class="tabs-para tab-pane fade in active" id="home" aria-labelledby="home-tab">
					<h5><span class="quote1"></span>“I immediately liked Incrediblybuilt's approach of making real estate investing as easy as buying stocks. And partnering with Incrediblybuilt has allowed me to add real estate to my portfolio through a simple purchasing and investment process.”<span class="quote2"></span></h5>
					<div class="clearfix"></div>
				</div>
				<div role="tabpanel" class="tabs-para tab-pane fade" id="profile" aria-labelledby="profile-tab">
					<h5><span class="quote1"></span>“I liked the idea of having a service provider that handled all the details from property acquisition through property management.”<span class="quote2"></span></h5>
					<div class="clearfix"></div>
				</div>
				<div role="tabpanel" class="tabs-para tab-pane fade" id="return" aria-labelledby="return-tab">
					<h5><span class="quote1"></span>“As a first-time investor, it was extremely beneficial for me to receive expert guidance from one of Incrediblybuilt's Real Estate Solutions Managers. He was very informative and thoroughly answered all my questions.”<span class="quote2"></span></h5>		
					<div class="clearfix"></div>
				</div>
				<div role="tabpanel" class="tabs-para tab-pane fade" id="team4" aria-labelledby="team4-tab">
					<h5><span class="quote1"></span>“We are now proud owners of two single-family home rentals in emerging markets that show positive monthly cash flow and equity growth”<span class="quote2"></span></h5>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="videoModal" aria-hidden="true">
  	<div class="modal-dialog">
	   	<div class="modal-content">
		    <div class="modal-body">
		     <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		 	<div>
		  	<iframe width="100%" height="350" src="" allowfullscreen=""></iframe>
	 	</div>
    </div>
   </div>
  </div>
</div>

<script type="text/javascript">
   autoPlayYouTubeModal();
 function autoPlayYouTubeModal() {
   var trigger = $("body").find('[data-toggle="modal"]');
   trigger.click(function () {
   var theModal = $(this).data("target"),
   videoSRC = $(this).attr("data-theVideo"),
   videoSRCauto = videoSRC + "?autoplay=1";
   $(theModal + ' iframe').attr('src', videoSRCauto);
   $(theModal + ' button.close').click(function () {
   $(theModal + ' iframe').attr('src', videoSRC);
   });
   $('.modal').click(function () {
    $(theModal + ' iframe').attr('src', videoSRC);
   });
  });
}
</script>
<!--//footer-top-->