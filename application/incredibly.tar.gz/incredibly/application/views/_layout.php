<?php
$this->load->view('components/header');
$this->load->view($content);
$this->load->view('components/footer');
?>