<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Incrediblybuilt</title>
	<!-- for-mobile-apps -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<meta property="og:title" content="Vide">
	<meta name="keywords" content="">
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="img/favicon.ico" type="image/x-icon" rel="icon">

<link href="<?=base_url()?>assets/img/favicon.ico" type="image/x-icon" rel="shortcut icon">

<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/css/bootstrap.css">
<!-- Custom Theme files -->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/css/nav.css">

<link rel="stylesheet" type="text/css" href="assets/css/iconeffects.css">

<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/css/style.css">
<!-- js -->
<script type="text/javascript" src="<?=base_url()?>assets/js/jquery-1.11.1.min.js"></script>
<!-- //js -->
<!-- dropdown -->
<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.easydropdown.js"></script>
<!-- //dropdown -->
<!--webfont-->
<link href='<?=base_url()?>assets/css/css.css?family=Nunito:400,300,700' rel='stylesheet' type='text/css'>

<link href='<?=base_url()?>assets/css/css-1.css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="<?=base_url()?>assets/js/move-top.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- accordian -->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/css/jquery-ui.css">

<script type="text/javascript" src="<?=base_url()?>assets/js/jquery-ui.js"></script>

<script type="text/javascript" src="<?=base_url()?>assets/js/bootstrap.js"></script>

<script>
	$(function() {
		$( "#accordion" ).accordion();
	});
</script>
<!-- //accordian -->
<!-- tabs -->
<script type="text/javascript" src="<?=base_url()?>assets/js/easyResponsiveTabs.js"></script>	
<script type="text/javascript">
	$(document).ready(function () {
		$('#horizontalTab').easyResponsiveTabs({
			type: 'default',          
			width: 'auto', 
			fit: true  
		});
	});				
</script>
<!-- //tabs -->
<!--animate-->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/css/animate.css">
<script type="text/javascript" src="<?=base_url()?>assets/js/wow.min.js"></script>	
<script>
	new WOW().init();
</script>
<!--//end-animate-->
</head>
<body>
	<div id="container">
		<div id="header">
		</div>
		<div id="content">
			<div class="container">
				<div class="row">
				</div>	
			</div>
			<div class="page-head">
				<div class="header-nav">
					<div class="logo wow fadeInUp animated" data-wow-delay=".5s">
						<h1>
							<a class="link link--kumya" href="<?=base_url() ?>"><i></i><span data-letters="Incrediblybuilt">Incrediblybuilt</span></a>
						</h1>
					</div>
					<div class="top-nav wow fadeInUp animated" data-wow-delay=".5s">								 
						<label class="mobile_menu" for="mobile_menu">
							<span>Menu</span>
						</label>
						<input id="mobile_menu" type="checkbox">
						<ul class="nav">
							<li><a href="<?=base_url() ?>" title="home">home</a></li>

							<li><a href="<?=base_url() ?>about" title="about">about</a></li>

							<li><a href="<?=base_url() ?>contact-us" title="get-started">Contact Us</a></li>

							<li><a href="#" data-toggle="modal" data-target="#myModal" id="showlogin">Login</a></li>

							<li><a href="<?=base_url() ?>get-started" title="get-started">get-started</a></li>
						</ul>
					</div>
					<div class="clearfix"></div>	
				</div>
			</div> 