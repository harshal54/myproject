<div class="footer">
	<div class="container">
		<div class="col-md-4 col-sm-6 col-xs-12 footer-grid wow fadeInRight animated" data-wow-delay=".5s">
			<h3>Navigation</h3>
			<ul>
				<li><a href="<?=base_url()?>" title="home">Home</a></li>
				<li><a href="<?=base_url()?>about" title="about">About Us</a></li>
				<li><a href="#" data-toggle="modal" data-target="#myModal" id="showlogin">Login</a></li><li><a href="<?=base_url()?>get-started" title="get-started">Get-Started</a></li> 
			</ul>
		</div>
		<div class="col-md-4 col-sm-6 col-xs-12 footer-grid wow fadeInLeft animated" data-wow-delay=".5s">
			<h3>Get in Touch</h3>
			<h2>Incrediblybuilt</h2>
			<style type="text/css">
			.ftr-img{
				padding: 10px 0;
			}
		</style>
		<ul>
			<li><img src="<?=base_url()?>assets/img/phone no.png" alt="" class="img-responsive ftr-img"></li>
			<li><img src="<?=base_url()?>assets/img/address.png" alt="" class="img-responsive ftr-img"></li>
			<li><img src="<?=base_url()?>assets/img/email.png" alt="" class="img-responsive ftr-img"></li>
		</ul>
	</div>
	<div class="col-md-4 col-sm-6 col-xs-12 social-grid wow fadeInLeft animated" data-wow-delay=".5s">
		<h3>Connect online</h3>
		<ul>
			<li><a class="fb1" href="javascript:;"></a></li>
			<li><a class="fb2" href="javascript:;"></a></li>
			<li><a class="fb3" href="javascript:;"></a></li>
		</ul>
		<p class="successnews"></p>
		<form action="<?php base_url(); ?>newsletter" role="form" id="sendNewsletter" method="post">
			<input type="email" placeholder="Enter your email" required="" name="user_email" data-error="Valid email is required." id="file-input">
			<input type="submit" class="sendNewsletter" name="subscribe" value=" ">
		</form>
	</div>
	<div class="clearfix"></div>
	<div class="copy-right">
		<p>2018 © All Rights Reserved.</p>
	</div>
</div>
</div>
<!-- //footer-->
<!-- Modal -->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content" id="loginForm">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body modal-spa">
				<div class="login-grids">
					<span class="successMsg"></span>
					<div class="login">
						<div class="login-right">
							<form method="post" id="userlogin" action="">
								<h3 class="errorMsg"></h3>
								<h3>LOG IN </h3>
								<input type="email" name="email" placeholder="Please enter your email *" required="">
								<input type="password" name="password" placeholder="Password *" required="">	
								<input type="submit" value="LOGIN">
								<a class="usersign_btn" id="hideLogin" href="#" data-toggle="modal" data-target="#sign">SIGN UP</a>
							</form>
						</div>
						<div class="clearfix"></div>
					</div>
					<p>By logging in you agree to our <a href="<?=base_url()?>terms-and-conditions" class="" title="Terms and Conditions">Terms and Conditions</a> and <a href="<?=base_url()?>privacy-policy" class="" title="Privacy Policy">Privacy Policy</a></p>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="sign" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body modal-spa">
				<div class="login-grids">
					<div class="login">
						<div class="login-left">

						</div>
						<span class="successhead"></span>
						<h4 class="successsignin"></h4>
						<h4 class="query-cont text-center"></h4>
						<div class="login-right login-right1">
							<span class="erroremail"></span> 
							<form role="form" id="usersignup" method="post" action="">
								<h3>Signup with your account </h3>
								<input type="text" name="name" placeholder="Please enter your name *" required="">	
								<input type="text" name="email" placeholder="Please enter your email *" required="" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$">	
								<input type="password" name="password" placeholder="password *" required="" name="password" minlength="8" maxlength="16">
								<input type="text" name="phone" placeholder="phone *" required="" maxlength="12" minlength="10">
								<input type="submit" value="SIGN UP">
							</form>
						</div>
						<div class="clearfix"></div>								
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$('#usersignup').submit(function(){
	var formData = $(this).serialize();
		$.ajax({
			url:"<?= base_url('signupdetails');?>",
			method:"post",
			dataType:'json',
			data: formData,
			success: function(res){
				
		if(res.status == 1){

			$('.successhead').text('Thank you for signing up for Incrediblybuilt account.');
			$('.successsignin').text('We have sent you confirmation mail at your email Id. Please check you inbox and also spam folder for confirmation of account.');
			$('.query-cont').html('If you have any queries please <a href="<?php base_url(); ?>contact-us" class="contactus" title="Contact Us">contact us.</a>');
			$('.loginButton').html('<button type="button" class="btn btn-danger" style="border: none; background-color: #E21737;">Login Here</button>');
			$('.login-right').css('display', 'none');
		}else if(res.msg == 'Failure'){
			$('.errorMsg').text('Sorry!!! Please, try again.');
		}else if(res.msg == 'alreadyExit'){
			$('.erroremail').text('Email already exists! Please use other Email Id');
		}
	}
});
return false;
});
</script>
<script>
	$(document).ready(function () {
		$('#sendNewsletter').submit(function(e){
//e.preventdefault();
var email = $(this).serialize();
$.ajax({
			url:"<?= base_url('newsletter');?>",
			method:"post",
			dataType:'json',
			data: email,
			success: function(res){
		if(res.status == 1){
			$('.successnews').text('Thanks for Sign up Newsletter. We will revert you as soon as possible.');
			$("#file-input").val(null);
		}else{
			$('.errorMsg').text('Sorry!!! Please, try again.');
		}
	}
});
return false;
});
	});
</script>
<script>
	$(document).ready(function () {
		$('#userlogin').submit(function(e){

        e.preventDefault()
			var formData = $(this).serialize();
				$.ajax({
				method: 'POST',
				url: '<?php echo base_url('logindetails');?>',
				data: formData,
				dataType:'json',
				success: function(res){
					
					if(res.status == 1)
					{
                		$('.errorMsg').html(res.msg);	
                	}else
                	{
                		$('.errorMsg').html(res.msg);
                	}
					},
				
			});
			return false;
		});
	});
	
</script>
