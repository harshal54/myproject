<div class="container-fluid portfolio portfolio-buffer">
	<div class="container tophead">
		<div class="row">
			<div class="col-lg-12">
				<h3>Portfolio Builder</h3>
				<p class="portfolio-para">Build a portfolio of properties that is uniquely based on your preferences and investment criteria. Portfolio Builder gives you insight into the returns you could achieve by investing in real estate. When using this tool, we recommend you look appealing portfolios and place your order for searched home list.</p>
			</div>
			<div class="col-lg-12">
				<form  id="sendData" action="">	
					<div class="form-group">		
						<div class="col-lg-3">
							<label class="label-control">Location</label>
							<select  name="location" class="form-control" required>
								<option value="" selected="selected">Any</option>
								<option value="northnewjersey" >North New Jersey</option>
								<option value="centralnewjersey" >Central New Jersey</option>
								<option value="southnewjersey" >South New Jersey</option>
							</select>
							<span id="err_loc" class="error"></span>	
						</div>
						<div class="col-lg-2">
							<label class="label-control">Investment Amount</label>
							<input type="text" name="investment_budget" class="form-control" value="121212">
							<span id="err_amount" class="error"></span>
						</div>
						<div class="col-lg-2">

							<label class="label-control">Financing</label>
							<select name="finance_preferance" class="form-control" required>
								<option value="" selected="selected">Any</option>
								<option value="Financed" selected>Financed</option>
								<option value="All Cash" >All Cash</option>
							</select>
							<span id="err_finance" class="error"></span>
						</div>
						<div class="col-lg-2">
							<label class="label-control">Investment Strategy</label>
							<select class="form-control" name="investment_strategy" required>
								<option value="" selected="selected">Any</option>
								<option value="Income" >Income</option>
								<option value="Wealth Builder" >Wealth Builder</option>
								<option value="Wealth Protection" >Wealth Protection</option>
							</select>
							
						</div>
						<div class="col-lg-3 tophead">
							<input type="submit" name="portfolio" class="submit action-button" id="btn1" value="Search Listing"/>
						</div>
					</div>
				</form>
			</div>
			<div class="col-md-12 col-sm-12 col-xs-12">
				<h1 class="error-msg text-center"></h1>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$("#sendData").submit(function(e){
			e.preventDefault();
			$('.error-msg').text('No Result Found !!');
		});
	});
</script>
<style type="text/css">
	.error-msg{
		margin: 50px 0px;
	}
</style>