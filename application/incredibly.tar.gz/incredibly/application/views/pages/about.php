<section class="page-header" style="background-image:url('<?=base_url()?>assets/img/about-hero-1.jpg');">
	<div class="banner-info">
	<h2>Incrediblybuilt Helps You Invest in Real Estate</h2>
	</div>
</section>
<!-- about -->
<div class="about-page">
	<div class="container">
		<h3 class="tittle1 tittle2">Find a wealth of information here to help you on your real estate investing journey.</h3>
			<div class="why-grids">
				<div class="col-md-12  wow fadeInLeft animated why-grand" data-wow-delay=".5s">
		          <p>From updates on industry trends to real estate investing tips, you can find it all on our blog. With hundreds of articles in our database and new ones becoming readily available weekly, you’re bound to learn a new thing or two! Expand your real estate investing knowledge by heading to our blog now.</p>	
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	</div>
</div>
<div class="Need-help">
	<div class="container text-center Need-help-block">
		<h4>Need help investing?</h4>
		<p>We have experienced real estate investment professionals</p>
		<p>standing by to answer any questions you may have.</p>
		<a href="mailto:info@Incrediblybuilt.com "><button type="button" class="btn btn-info Need-helpbtn"> EMAIL US</button></a>
		<a href="<?=base_url()?>contact-us"><button type="button" class="btn btn-info Need-helpbtn"> CALL US</button></a>
	</div>
</div>