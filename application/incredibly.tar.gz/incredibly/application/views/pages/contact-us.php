<div class="contact">
	<div class="container">
		<h3 class="tittle">View On map</h3>
		<body>
			<div class="map wow fadeInUp animated" data-wow-delay=".5s">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3035.1519428893325!2d-74.49941988523564!3d40.47190346020714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c3c6aae54afff9%3A0x4447259592bd2325!2s46%20Bennetts%20Ln%2C%20Somerset%2C%20NJ%2008873%2C%20USA!5e0!3m2!1sen!2sin!4v1633586561013!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy">
				</iframe>
			</div>
		</body>
		<div class="col-md-12 col-sm-12 col-xs-12 text-center">
		</div>
		<h3 class="tittle">Contact</h3>
		<p class="successContact text-center"></p>
		<p class="errorContact"></p>
		<div class="contact-grids">
			<div class="col-md-7 contact-grid wow fadeInUp animated " data-wow-delay=".5s">
				<form action="<?=base_url()?>contactdetails"  id="sendContact" method="post" >
					<div style="display:none;">
						<input type="hidden" name="_method" value="POST">
					</div>
					<div class="input text">
						<label for="form_name">

						</label>
						<input name="name" class="form-control " id="form_name" placeholder="Please enter your name: *" required=""  type="text">
					</div>
					<div class="input email">
						<label for="form_email"></label>
						<input name="email" class="form-control" id="form_email" placeholder="Please enter your email: *" required=""  type="email">
					</div>
					<div class="input text">
						<label for="form_phone">
						</label>
						<input name="phone" class="form-control" id="form_phone" placeholder="Please enter your phone:" type="text">
					</div>
					<div class="input textarea">
						<label for="form_message">
						</label>
						<textarea name="message" class="form-control" id="form_message" placeholder="Message: *" required="" rows="4" cols="30" required="">
						</textarea>
					</div>
					<div class="submit">
						<input type="submit" value="Send" class="pull-right">
					</div>
				</form>	
			</div>
			<div class="col-md-5 contact-grid wow fadeInUp animated contact-grid1 " data-wow-delay=".5s">
				<div class="call ">
					<div class="col-xs-3 contact-grdl">
						<span class="glyphicon glyphicon-phone" aria-hidden="true"></span>
					</div>
					<div class="col-xs-9 contact-grdr">
						<ul>
							<li><img src="<?=base_url()?>assets/img/phone no.png" alt="" class=" img-responsive ftr-img"></li>
						</ul>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="call">
					<div class="col-xs-3 contact-grdl">
						<span class="glyphicon glyphicon-send" aria-hidden="true"></span>
					</div>
					<div class="col-xs-9 contact-grdr">
						<style type="text/css">
						.ftr-img{
							padding: 10px 0;
						}
					</style>
					<ul>
						<li><img src="<?=base_url()?>assets/img/address.png" alt="" class="img-responsive ftr-img"></li>
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="call">
				<div class="col-xs-3 contact-grdl">
					<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
				</div>
				<div class="col-xs-9 contact-grdr">
					<ul>
						<li><img src="<?=base_url()?>assets/img/email.png" alt="" class="img-responsive ftr-img"></li>
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
</div>
</div>
<script>
	$('#sendContact').submit(function(){
		var formData = $(this).serialize();
		$.ajax({
			url:"<?= base_url('contactdetails');?>",
			method:"post",
			dataType:'json',
			data: formData,
			success: function(res){

				if(res.status==1){
					$('.successContact').html(res.msg);
					$('.contact-grids').css('display', 'none');
				}else{
					$('.errorContact.').html(res.msg);
				}
			}
		});
		return false;
	});
</script>