<div class="container">
	<div class="row">
		
	
	<form method="post" name="msform" id="msform" action="<?php echo base_url(); ?>portfolio">
	<!-- progressbar -->
	<ul id="progressbar">
		<li class="active"></li>
	      <li></li>
		<li></li>
   </ul>
	<!-- fieldsets -->
	<style>
		.port{
			position: initial!important;
		}
	</style>
<fieldset class="port">
	<h1 class="fs-title"><b>What is your investment strategy?</b></h1>
		<span class="error" id="strategy"></span>
		<div class="form-group form-buffer">
			<input type="radio" name="investment_strategy" value="Income" id="r1">&nbsp;Income
		</div>

		<div class="form-group form-buffer">
			<input type="radio" name="investment_strategy" value="Wealth Builder" id="r1">&nbsp;Wealth Builder
		</div>

		<div class="form-group form-buffer">
			<input type="radio" name="investment_strategy" value="Wealth Protection" id="r2">&nbsp;Wealth Protection
		</div>

		<div class="form-group form-buffer">
			<input type="radio" name="investment_strategy" value="I Don't know" id="r3">&nbsp;I Don't know
		</div>

		<input type="button" name="next" class="next action-button" value="Next">
	</fieldset>

	<fieldset class="port">

		<h2 class="fs-title"><b>My initial investment in real estate would be around</b></h2>
		<div class="form-group">
			<input type="text" name="investment_budget" class="form-control text" id="investment_budget" placeholder="$25, 000">
			<span class="error" id="invest"></span>
		</div>

		<input type="button" name="previous" class="previous action-button" value="Previous">
		<input type="button" name="next" class="next action-button" value="Next">

	</fieldset>
	<fieldset class="port">
		<h2 class="fs-title"><b>My financing preference is</b></h2>
		<span class="error" id="finance_pre"></span>
		<div class="form-group form-buffer">
			<input type="radio" name="finance_preferance" value="Financed">&nbsp;Financed
		</div>

		<div class="form-group form-buffer">
			<input type="radio" name="finance_preferance" value="All Cash">&nbsp;All Cash
		</div>

		<input type="button" name="previous" class="previous action-button" value="Previous">
		<input type="submit" name="portfolio" class="submit action-button" id="showPortfolio" value="Build Portfolio">
	</fieldset>
</form>
</div>
</div>

<script>
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches
var cnt = 0;
var pre = 0;
$(".next").click(function(e){
   document.getElementById('strategy').innerHTML='';
   document.getElementById('invest').innerHTML='';
   document.getElementById('finance_pre').innerHTML='';
   var status = 0;
//alert(cnt);
if(cnt == 0){
   var selected = $("input[type = 'radio'][name = 'investment_strategy']:checked");
   if(selected.length == 0){
//alert('Please select one item');
document.getElementById('strategy').innerHTML='Please select one option';
status = 1;
}
}
if(cnt >= 1){
   var txt = $("#investment_budget").val();
   var regex = /^[1-9]\d*(((,\d{3}){1})?(\.\d{0,2})?)$/;
   if(txt.length ==0){
//alert('Please fill this field');
document.getElementById('invest').innerHTML='Please fill this field';
status = 1;
}
else if(!txt.match(regex)){
   document.getElementById('invest').innerHTML='Invalid Amount';
   status = 1;
}
}
//
if(pre == 1){
   status =0;
}
if(status == 0){
   if(animating) return false;
   animating = true;
   current_fs = $(this).parent();
   next_fs = $(this).parent().next();

//activate next step on progressbar using the index of next_fs
$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

//show the next fieldset
next_fs.show(); 

//hide the current fieldset with style
current_fs.animate({opacity: 0}, {
   step: function(now, mx) {
//as the opacity of current_fs reduces to 0 - stored in "now"
//1. scale current_fs down to 80%
scale = 1 - (1 - now) * 0.2;
//2. bring next_fs from the right(50%)
left = (now * 50)+"%";
//3. increase opacity of next_fs to 1 as it moves in
opacity = 1 - now;
current_fs.css({
   'transform': 'scale('+scale+')',
   'position': 'absolute'
});
next_fs.css({'left': left, 'opacity': opacity});
}, 
duration: 800, 
complete: function(){
   current_fs.hide();
   animating = false;
}, 
//this comes from the custom easing plugin
easing: 'easeInOutBack'
});
pre =0;
cnt++; 
}  
});
$(".previous").click(function(){
   pre = 1;
   if(animating) return false;
   animating = true;
   current_fs = $(this).parent();
   previous_fs = $(this).parent().prev();
//de-activate current step on progressbar
$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
//show the previous fieldset
previous_fs.show(); 
//hide the current fieldset with style
current_fs.animate({opacity: 0}, {
   step: function(now, mx) {
//as the opacity of current_fs reduces to 0 - stored in "now"
//1. scale previous_fs from 80% to 100%
scale = 0.8 + (1 - now) * 0.2;
//2. take current_fs to the right(50%) - from 0%
left = ((1-now) * 50)+"%";
//3. increase opacity of previous_fs to 1 as it moves in
opacity = 1 - now;
current_fs.css({'left': left});
previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
}, 
duration: 800, 
complete: function(){
   current_fs.hide();
   animating = false;
}, 
easing: 'easeInOutBack'
});
});
$(".portfolio").hide();
$("#showPortfolio").click(function(){
   var selected2 = $("input[type = 'radio'][name = 'finance_preferance']:checked");
   if(selected2.length == 0){
//alert('Please select one item');
document.getElementById('finance_pre').innerHTML='Please select one preference';
return false;
}
else{
   $(".portfolio").show();
   $("#msform").hide();
}
});
</script>