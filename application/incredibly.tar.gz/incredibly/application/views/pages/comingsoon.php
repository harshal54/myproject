<section class="page-header" style="background-image:url('<?=base_url()?>assets/img/getstarted.jpg');">
		<div class="banner-info">
		<h2>Build Your Real Estate Portfolio</h2>
		</div>
</section>
<div class="contact">
	<div class="container">
		<h3 class="tittle">Coming Soon</h3>
	</div>
</div>