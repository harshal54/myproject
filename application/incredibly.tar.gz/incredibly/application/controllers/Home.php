<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	
	public function index()
	{
		$data['content'] = 'frontpage';
		$this->load->view('_layout',$data);
	}
		public function page()
	{
		$pageName        = end($this->uri->segments);
		$data['content'] = 'pages/'.$pageName;
		$this->load->view('_layout',$data);
	}
	
	public function contactdetails()
	{
		$data['name']    =$this->input->post('name');
		$data['email']   =$this->input->post('email');
		$data['phone']   =$this->input->post('phone');
		$data['message'] =$this->input->post('message');

		$insertData = $this->db->insert('contact_us',$data);
		 if($insertData)
         {
         	$result = array("status" =>1,"msg"=>"Thank you for contacting us! We appreciate you contacting us. We will try to respond you as soon as possible." );
         }
         else
         {
         	$result = array("status" =>0,"msg"=>"Sorry!!! Please, try again.");
	     }
	 echo json_encode($result);

}

public function signupdetails()
{
	$data['name']      =$this->input->post('name');
	$data['email']     =$this->input->post('email');
	$data['password']  =md5($this->input->post('password'));
	$data['phone']     =$this->input->post('phone');

	$this->db->where('email',$data['email'] );
	$query = $this->db->get('signup');
	if($query->num_rows() > 0)
	{
		$result=array("status"=>0,"msg"=>"alreadyExit");
	}
	else
	{
		$insertData = $this->db->insert('signup',$data);
		if($insertData)
		{
			$result = ["status" =>1];

		}
		else
		{
			$result = ["status" =>0];
		}
	}
	echo json_encode($result);
}

public function logindetails()
{

	         $email     =$this->input->post('email');
	         $password  =md5($this->input->post('password'));
             $query     = $this->db->get_where('signup',array('email'=>$email,'password'=>$password));
             $user      = $query->row();
             if($query->num_rows() > 0){ 

             	if($user->status == '1')
             	{
             		 $result=array("status"=>1,"msg"=>"Your Account Has Activated");
             	}
             	else{

             		 $result=array("status"=>1,"msg"=>"Your Account Has Not Activated");
             	}

             }else{

             	 $result=array("status"=>0,"msg"=>"Invalid Email or Password");
             }
                
             echo json_encode($result);
}

public function newsletter()
{
	$data['email']=$this->input->post('user_email');

	$insertEmail = $this->db->insert('newsletters',$data);
	if($insertEmail)
		{
			$result = ["status" =>1];

		}
		else
		{
			$result = ["status" =>0];
		}
		echo json_encode($result);
	}
}
